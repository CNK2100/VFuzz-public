
#define ASCIIOFFSET 0x20

//6 bytes wide
//Each byte is 8 pixels tall

#define fontSIZE 768

void putch(char ch);
